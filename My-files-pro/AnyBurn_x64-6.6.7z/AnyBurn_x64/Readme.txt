                           AnyBurn Overview
            Copyright(C) 2011-2025 Power Software Ltd
                     All Rights Reserved

AnyBurn is a light weight but professional CD / DVD / Blu-ray burning 
software that every one must have. It provides a free and complete solution 
for burning. You needn't pay for this free burn software!

Main Features:
1.  Burn image file to disc
2.  Burn files and folders to disc
3.  Burn Audio CD from mp3, flac, ape, wma, wav files
4.  Erase rewritable disc
5.  Copy disc to image file
6.  Copy disc to another disc
7.  Browse or extract image file
8.  Edit image file
9.  Create image file from files and folders
10. Convert image files
11. View drive and disc information
12. Rip Audio CD to mp3, flac, ape, wma, wav files.
13. Create bootable USB drive
14. Test disc sectors

Power Software Ltd

Home Page: http://www.anyburn.com
   E-Mail: support@anyburn.com

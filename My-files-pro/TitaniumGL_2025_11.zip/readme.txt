Q: Where to download TitaniumGL?
A: http://TitaniumGL.atw.hu


Q: Where to put the DLL file?
A: Search the EXE file of the OpenGL based game or program. Put the OpenGL32.DLL file there.


Q: The 64 or 32 bit version should be used on a 64 bit system?
A: If the application is 32 bit, then the 32 bit version of the dll has to be used. If the application is 64 bit, the 64 bit version should be used.


Q: Why the 64 bit version called opengl32.dll?
A: There are some questions when the universe can not provide an answer for you.



Please read the version history and the documentation on the website.
